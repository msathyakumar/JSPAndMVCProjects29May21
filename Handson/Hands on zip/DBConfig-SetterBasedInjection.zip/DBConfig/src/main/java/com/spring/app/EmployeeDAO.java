package com.spring.app;

public class EmployeeDAO {
    private DBConfig dbConfig;

	public DBConfig getDbConfig() {
		return dbConfig;
	}

	public void setDbConfig(DBConfig dbConfig) {
		this.dbConfig = dbConfig;
	}
	
}