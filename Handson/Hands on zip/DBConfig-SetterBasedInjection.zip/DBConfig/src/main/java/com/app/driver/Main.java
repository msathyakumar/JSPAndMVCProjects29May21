package com.app.driver;

import org.springframework.context.ApplicationContext ;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.spring.app.EmployeeDAO;
import com.spring.app.DBConfig;
public class Main {
 
	@SuppressWarnings("resource")
	public static void main(String[] args) {
	    ApplicationContext  apc = new ClassPathXmlApplicationContext("beans.xml");
	    EmployeeDAO emp =(EmployeeDAO)apc.getBean("employeeDAO");
	    DBConfig dbco = emp.getDbConfig();
	    
	    System.out.println(dbco.getDriverName());
	    System.out.println(dbco.getUrl());
	    System.out.println(dbco.getUserName());
	    System.out.println(dbco.getPassword());
 
 
    


 
		
	}
}