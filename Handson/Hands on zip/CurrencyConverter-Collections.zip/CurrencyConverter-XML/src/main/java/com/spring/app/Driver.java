package com.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Driver {
	
public static void main(String[] args)
{

        ApplicationContext apcon = new ClassPathXmlApplicationContext("beans.xml");
	    CurrencyConverter ccon = (CurrencyConverter)apcon.getBean("curenConvBean");
	    int finalValue = ccon.getTotalCurrencyValue("5Dollar");
	    System.out.println(finalValue);
	
}

}
