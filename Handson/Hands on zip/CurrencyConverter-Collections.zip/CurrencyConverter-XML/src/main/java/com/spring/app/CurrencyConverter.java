package com.spring.app;
import java.util.Map;

public class CurrencyConverter {
    
        private Map<String,String> mObj;
        
        
        public Map<String, String> getmObj() {
    		return mObj;
    	}
    
    	public void setmObj(Map<String, String> mObj) {
    		this.mObj = mObj;
    	}
    	
	    public int getTotalCurrencyValue(String value)
    	{
    	    String fin = "";
		    int nextind = 0;
    	    for(int i=0;i<value.length();i++) {
    		char ct = value.charAt(i);
    		if(Character.isDigit(ct)) {
    			fin +=ct;
    			nextind = i+1;
    	        }
    	}
	    //int i = Integer.parseInt(value.substring(0,1));
    	int i = Integer.parseInt(fin);
    	    
    	    String str = (String)value.substring(nextind).toUpperCase();
    	    if(str!=null){
    	    	
    	        String str1 = value.substring(1);
    	        int cost = Integer.parseInt(mObj.get(str));
    	        return i*cost;
    	   
    	    }
    	    else{
    	    
	        return 0;
    	    }
    	    
	 
	    }	
	
		    	    	     	      	 	

}
