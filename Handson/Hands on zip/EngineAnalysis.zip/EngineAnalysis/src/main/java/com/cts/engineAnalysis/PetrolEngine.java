package com.cts.engineAnalysis;

public class PetrolEngine  extends Engine {
    

public int getPerformance() {

		return super.getTorque() * super.getRpm() / 5252;
	}
	
	

}
