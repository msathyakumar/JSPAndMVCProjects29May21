package com.cts.passportService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

// Type your code here
public class BangalorePassportOffice  {

	private Document bangaloreDocument;
		
    // Type your code here
	public BangalorePassportOffice(Document bangaloreDocument) {
		super();
		this.bangaloreDocument = bangaloreDocument;
	}

	
	// Type your code here

	

}
