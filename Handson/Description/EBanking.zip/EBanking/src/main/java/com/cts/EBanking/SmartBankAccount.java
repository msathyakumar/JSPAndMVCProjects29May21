package com.cts.EBanking;

import java.text.DecimalFormat;
import java.util.List;

public class SmartBankAccount  {
	
	SmartBankAccount(){
		
	}
	
   // type  your code here
   
   
	

	
}
