package com.cts.engineAnalysis;

public class Car {
	
	private String name;
	private Engine engine;
	
	// Type your code here
	
	public void getReport(){
		
    // Type your code here
		
	}

}
